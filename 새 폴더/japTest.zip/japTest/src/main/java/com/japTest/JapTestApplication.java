package com.japTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JapTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JapTestApplication.class, args);
	}

}
